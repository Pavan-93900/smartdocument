import streamlit as st
import PyPDF2
from groq import Groq

# Initialize Groq client
client = Groq(api_key="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")

st.title("🧠 Smart AI Assistant Document Management (Using Groq API)")

# Upload file
uploaded_file = st.file_uploader("Upload a PDF", type="pdf")

if uploaded_file:
    # Read PDF
    pdf_reader = PyPDF2.PdfReader(uploaded_file)
    text = ""
    for page in pdf_reader.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text

    st.success("File uploaded and text extracted!")

    # Show options
    task = st.radio("Select task:", ["Ask Questions", "Summarize Document"])

    if task == "Ask Questions":
        user_question = st.text_input("Ask your question:")

        if user_question:
            with st.spinner("Thinking..."):
                prompt = f"""Document content: {text}
                
                Based on the above document, answer this question: {user_question}"""
                
                response = client.chat.completions.create(
                    messages=[
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    model="mixtral-8x7b-32768",  # You can change to "llama2-70b-4096" if preferred
                    temperature=0.5,
                )
                st.subheader("Answer:")
                st.success(response.choices[0].message.content)

    elif task == "Summarize Document":
        if st.button("Summarize Now"):
            with st.spinner("Summarizing..."):
                prompt = f"""Summarize this document into a concise paragraph:
                
                {text}"""
                
                response = client.chat.completions.create(
                    messages=[
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    model="mixtral-8x7b-32768",
                    temperature=0.3,
                )
                st.subheader("Summary:")
                st.info(response.choices[0].message.content)